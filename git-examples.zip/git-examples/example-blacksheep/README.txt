A sample repository containing the nursery rhyme "Baa, baa, black sheep"
